var a = 10;
var b = 20; 
// export default a; 
export {a, b}; // 중괄호
export default c;
